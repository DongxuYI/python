def receive():
    print("这是来自远方的信息")