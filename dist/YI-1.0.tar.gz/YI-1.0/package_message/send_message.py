def send(msg):
    print(msg)